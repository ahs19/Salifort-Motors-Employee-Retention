# v0.11 validation (14 October 2026)

**Status:** v0.10 has run on the real model. v0.11 is ready for its first
real-model run.

- **v0.10 on a Colab A100** (Qwen2.5-3B-Instruct, bf16, 6 runs, about 4
  minutes each) ran cleanly. The self-model improved itself and the gain
  transferred in all six runs. The strategy did so in one of three plans. The
  analysis is in [`docs/v0.10-a100-results.md`](docs/v0.10-a100-results.md).
- **v0.11** changes how the strategy is revised (one appended rule per
  proposal), based on that evidence. Its inference path is unchanged from
  v0.10 and was re-tested below against the real libraries with a tiny
  locally built Qwen2-architecture model on CPU. Real Qwen2.5-3B weights are
  not available in this container, because its network policy blocks
  huggingface.co.

The real experiment is
`release/v0.11.0/Digital_Mirror_Recursive_v0_11.ipynb` on a Colab GPU. Its
preflight cell is the first real-model check.

## Software checks

```text
python -B -m unittest discover -s tests -v
  Python 3.11, 3.12, 3.13 (standard library only): 115 tests, OK (7 opt-in skipped)
RECURSIVE_MIRROR_TEST_DEVICE=cpu python -B -m unittest discover -s tests
  Python 3.12 + torch 2.14.1 + transformers 4.57.6: 115 tests, OK
```

| test module | tests | covers |
|---|---|---|
| test_core | 65 | the recursive engine (details below) |
| test_runtime | 25 | checkpoints, the HF backend, the CLI, report wording, `--exclude-state` continuation |
| test_tasks | 6 | `make-plan`, re-deriving every expected answer from the prompt text |
| test_experiment | 6 | replicated runs, control arm, failure isolation, pooled statistics, CLI |
| test_release | 6 | archive, notebook order and budgets; the committed release must embed exactly the current sources |
| test_hf_integration | 7 | opt-in, real library stack (details below) |

`test_core` covers:

- live-stack recursion;
- frozen proposals;
- answer-key isolation;
- one lever per proposal kind;
- the gate, including the evidence bound;
- batching;
- caching;
- budgets, including wall-clock;
- regression tests that replay each v0.8 Colab failure;
- v0.11 rule proposals: target ranking, appending, screens for off-lever and
  copied text, truncated replies, and structured self-model extraction from
  replies that copy evidence after the per-type lines.

`test_runtime` covers:

- checkpoint v2/v1, tamper and limits;
- the HF backend contract: pure greedy decoding, filtered inputs, dtype;
- every CLI command.

`test_hf_integration` covers, on the real library stack:

- EOS and truncation;
- the input limit;
- **batched rows equal single requests exactly (CPU float32)**;
- a full recursive run;
- the CLI.

## What running the real stack found and fixed

- **Repetition penalty.** Qwen2.5's `repetition_penalty: 1.05` is applied
  under `do_sample=False` (confirmed: `RepetitionPenaltyLogitsProcessor` is
  active). Decoding is now plain argmax.
- `generate()` rejected `token_type_ids`. Only `input_ids` and
  `attention_mask` are passed now.
- `torch_dtype` is deprecated; the `dtype=` keyword is used where supported.
- Warnings about ignored sampling flags are gone, because the flags are
  cleared explicitly.

## End-to-end pipeline check

`python -m recursive_mirror experiment` ran with the real backend and a tiny
random model on CPU:

- 2 seeds × (self + control);
- 70 calls per run;
- batched generation;
- summary, reports and diagnostics.

The random model produces gibberish, and `diagnose` flagged exactly that:
every reply truncated, no `ANSWER:` lines, no valid forecasts. The preflight
shows the same check for the real model before the long run.

## Multi-agent review

Four specialist reviewers each had a paired skeptic:

- real inference and Colab;
- small-LLM protocol behaviour, using the v0.8 Qwen journals;
- selection statistics;
- persistence, CLI and tasks.

Confirmed or adopted findings are documented in
`docs/v0.8-trial-review.md` under "Found before the first v0.9 run".

A second round reviewed the v0.10 gate itself. Its six confirmed findings
(a non-monotonic gate, strategy candidates winning on calibration, a coverage
veto, forecast leaks, pooled-Brier counting and time reservation) are fixed,
each with regression tests.

The statistical-power finding changed the experiment sizes to 24 validation
and 48 final tasks per seed. For a genuine +15-point improvement, the chance
of committing it in a run rises from about 0.49 to about 0.79, and the
pooled analysis covers 144 held-out tasks.

## What this does not establish

These checks establish software behaviour, not learning. The v0.10 A100 run
showed transferable self-improvement of the self-model, and of the strategy
in one of three plans, for one 3B model and these task types. It did not beat
a hand-written step-by-step prompt. Whether v0.11's appended rules improve
the strategy more reliably is untested until the notebook runs. No awareness
claim is made.
