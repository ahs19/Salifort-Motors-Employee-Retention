# Recursive Mirror run report

- Protocol: `recursive-mirror-v0.10.0`
- Model: `scripted-test-double`
- Stop reason: `depth_limit`; LLM calls: 42 (plus 4 deterministic cache hits)
- Levels completed: 2; accepted improvements: 2
- **Outcome: the self-improved policy answered more held-out final tasks correctly (0% -> 100%) and was committed.**

## Final held-out comparison (n = 3)

| policy | accuracy | Brier | forecast coverage | mean forecast |
|---|---|---|---|---|
| initial | 0% | 0.640 | 100% | 80% |
| self-improved candidate | 100% | 0.000 | 100% | 99% |

Wins 3, losses 0. One-sided paired p-values: accuracy 0.125, calibration 0.125 (gate requires <= 0.25; exploratory, not a confirmatory test). Gate: passed (`accuracy_gain`).

## Level 0

Discovery: accuracy 0% on 1 tasks, mean forecast 80%. Parent on validation: accuracy 0%, Brier 0.640 (n = 2).

| candidate | gate | accuracy | paired Brier | wins/losses | p (acc / cal) |
|---|---|---|---|---|---|
| repair | **selected** (`accuracy_gain`) | 0% -> 100% | 0.640 -> 0.040 | 2/0 | 0.25 / 0.25 |
| recalibrate | passed (`calibration_gain`) | 0% -> 0% | 0.640 -> 0.010 | 0/0 | 1.00 / 0.25 |

<details><summary>repair proposal</summary>

Strategy:

```text
Apply order-of-operations: multiply before adding. Check the product, then add.
```

Self-model:

```text
My capabilities are uncertain. Use observed outcomes to calibrate forecasts.
```

</details>

<details><summary>recalibrate proposal</summary>

Strategy:

```text
Solve each task carefully. Return only the requested answer.
```

Self-model:

```text
Precedence tasks: unreliable, about 10% with this strategy.
```

</details>

## Level 1

Discovery: accuracy 100% on 1 tasks, mean forecast 80%. Parent on validation: accuracy 100%, Brier 0.040 (n = 2).

| candidate | gate | accuracy | paired Brier | wins/losses | p (acc / cal) |
|---|---|---|---|---|---|
| repair | ineligible (`unchanged`) | | | | |
| recalibrate | **selected** (`calibration_gain`) | 100% -> 100% | 0.040 -> 0.000 | 0/0 | 1.00 / 0.25 |

<details><summary>repair proposal</summary>

Strategy:

```text
Apply order-of-operations: multiply before adding. Check the product, then add.
```

Self-model:

```text
My capabilities are uncertain. Use observed outcomes to calibrate forecasts.
```

</details>

<details><summary>recalibrate proposal</summary>

Strategy:

```text
Apply order-of-operations: multiply before adding. Check the product, then add.
```

Self-model:

```text
Precedence tasks: reliable, about 99% with this strategy.
```

</details>

## Initial policy

Strategy:

```text
Solve each task carefully. Return only the requested answer.
```

Self-model:

```text
My capabilities are uncertain. Use observed outcomes to calibrate forecasts.
```

## Committed policy

Strategy:

```text
Apply order-of-operations: multiply before adding. Check the product, then add.
```

Self-model:

```text
Precedence tasks: reliable, about 99% with this strategy.
```

## Claim boundary

This run measures whether an inference-time strategy and self-model, revised by the model through recursive self-examination, improved exact-answer accuracy or forecast calibration on held-out tasks. Model weights were not changed. Small task sets give noisy estimates. Nothing here certifies awareness or consciousness.
