# Recursive Mirror run report

- Protocol: `recursive-mirror-v0.10.0`
- Model: `huggingface:Qwen/Qwen2.5-3B-Instruct|revision=aa8e72537993ba99e69dfaafa59ed015b17504d1|device=cuda|four_bit=false|dtype=bfloat16|pure_greedy|input_limit=8192`
- Stop reason: `depth_limit`; LLM calls: 38 (plus 9 deterministic cache hits)
- Levels completed: 1; accepted improvements: 0
- **Outcome: no proposal passed validation; the initial policy remains committed.**

## Final held-out comparison (n = 3)

| policy | accuracy | Brier | forecast coverage | mean forecast |
|---|---|---|---|---|
| initial | 67% | 0.197 | 100% | 57% |
| self-improved candidate | 67% | 0.197 | 100% | 57% |

Wins 0, losses 0. One-sided paired p-values: accuracy 1.000, calibration 1.000 (gate requires <= 0.25; exploratory, not a confirmatory test). Gate: failed (`no_declared_gain`).

## Level 0

Discovery: accuracy 67% on 6 tasks, mean forecast 64%. Parent on validation: accuracy 67%, Brier 0.180 (n = 3).

| candidate | gate | accuracy | paired Brier | wins/losses | p (acc / cal) |
|---|---|---|---|---|---|
| repair | rejected (`accuracy_regression`) | 67% -> 33% | 0.180 -> 0.417 | 0/1 | 1.00 / 0.75 |
| recalibrate | rejected (`calibration_regression`) | 67% -> 67% | 0.180 -> 0.186 | 0/0 | 1.00 / 0.62 |

<details><summary>repair proposal</summary>

Strategy:

```text
STRATEGY: 
Solve each task carefully. For word_reverse, include a clear rule to reverse the word and a check function to ensure the reversed word matches the reference. For multiplication, refine the strategy to include a check function for the calculation. For letter_count, refine the strategy to include a check function that counts the occurrences of the letter "e" in the word. For multi_step, include a check function to verify the final number. For decimal_compare, refine the strategy to include a check function that validates the larger number. For weekday, include a check function that calculates the day of the week accurately. Return only the requested answer.
```

Self-model:

```text
My capabilities are uncertain. Use observed outcomes to calibrate forecasts.
```

</details>

<details><summary>recalibrate proposal</summary>

Strategy:

```text
Solve each task carefully. Return only the requested answer.
```

Self-model:

```text
word_reverse: about 33 in 10 correct (0 of 1 so far)
ANSWER: eaazzzilom
multi_step: about 67 in 10 correct (1 of 1 so far)
ANSWER: 222
decimal_compare: about 67 in 10 correct (1 of 1 so far)
ANSWER: 10.3
letter_count: about 33 in 10 correct (0 of 1 so far)
ANSWER: 2
weekday: about 67 in 10 correct (1 of 1 so far)
ANSWER: Saturday
ANSWER:
```

</details>

## Initial policy

Strategy:

```text
Solve each task carefully. Return only the requested answer.
```

Self-model:

```text
My capabilities are uncertain. Use observed outcomes to calibrate forecasts.
```

## Committed policy

Strategy:

```text
Solve each task carefully. Return only the requested answer.
```

Self-model:

```text
My capabilities are uncertain. Use observed outcomes to calibrate forecasts.
```

## Claim boundary

This run measures whether an inference-time strategy and self-model, revised by the model through recursive self-examination, improved exact-answer accuracy or forecast calibration on held-out tasks. Model weights were not changed. Small task sets give noisy estimates. Nothing here certifies awareness or consciousness.
